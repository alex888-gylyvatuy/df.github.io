function heart_it (){
  "use-strict";
  document.getElementById("hearticon").style.backgroundImage = "url('https://cdn4.iconfinder.com/data/icons/e-commerce-icon-set/48/Like_2-48.png')";
}

function dontheart_it (){
  "use-strict";
  document.getElementById("hearticon").style.backgroundImage = "url('https://cdn4.iconfinder.com/data/icons/e-commerce-icon-set/48/Like-48.png')";
}
function follow (){
  "use-strict";
  document.getElementById("usericon").style.backgroundImage = "url('https://cdn4.iconfinder.com/data/icons/e-commerce-icon-set/48/Username_2-32.png')";
}

function dontfollow (){
  "use-strict";
  document.getElementById("usericon").style.backgroundImage = "url('https://cdn4.iconfinder.com/data/icons/e-commerce-icon-set/48/Username-48.png')";
}